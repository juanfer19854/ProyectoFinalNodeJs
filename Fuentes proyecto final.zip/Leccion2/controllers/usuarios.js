'use strict';
const {validationResult} = require('express-validator');

var Usuarios = require('../models/usuarios');
var controller = {
    usuarios: function (req, res)
    {
        Usuarios.find({}).exec((err, usuarios) => {
            if(err) return res.status(500).json({status : 500, mensaje : err});
            console.log(usuarios);
            return res.status(200).json({
                status: 200,
                data: usuarios
            }
            );
        });      
    },

    usuario: function (req, res)
    {
        //console.log(req);
        let n_mail = req.params.mail;
        Usuarios.findOne({mail : n_mail}).exec((err, usuario) => {
            if(err) return res.status(500).json({status : 500, mensaje : err});
            if(!usuario) return res.status(200).json({status :200, mensaje: "No se encontro el mail."});

            return res.status(200).json({
                status : 200,
                data: usuario

            });
        }


        );
          
    },

    crear_usuario: function (req, res)
    {
        //validacion de datos que se reciben
        const errors = validationResult(req);

        if(!errors.isEmpty()){
            return res.status(400).json({status : 400, errors : errors.array()});
        }

        

        let user_info = req.body;

        Usuarios.findOne({mail: user_info.mail}).exec((err, usuario) => {
            if(err) return res.status(500).json({status : 500, mensaje : err});
            if(usuario) return res.status(200).json({status :200, mensaje: "El usuario ya existe."});

            let usuarios_model= new Usuarios();
            usuarios_model.mail = user_info.mail ;
            usuarios_model.pass = user_info.pass ;




            usuarios_model.save((err, usuarioStored) => {
                if(err) return res.status(500).json({status : 500, mensaje : err});
                if(!usuarioStored) return res.status(200).json({status :200, mensaje: "No se almaceno el usuario."}); 
            });

            return res.status(200).json({
                status : 200,
                message: "Nuevo Usuario almacenado"
            });
        });
    },

    update_usuario: function (req, res){
        //validacion de datos que se reciben
        const errors = validationResult(req);

        if(!errors.isEmpty()){
            return res.status(400).json({status : 400, errors : errors.array()});
        }
        let n_mail = req.params.n_mail;
        let user_info = req.body;

        let usuario_info_update = {
            pass: user_info.pass        
        };

        //let alumnos_model= new Alumnos();
        Alumnos.findOneAndUpdate({mail: n_mail}, usuario_info_update,{new:true}, (err, usuarioUpdate) =>{
            if(err) return res.status(500).send({message: 'Error actualizando.'});
            if(!usuarioUpdate) return res.status(404).json({message: 'No existe el usuario.'});

            return res.status(200).json({ 
                mail: usuarioUpdate.mail,
                pass: usuarioUpdate.pass
                
            });

        //console.log(user_info);

        });
},

    Elimina_usuario: function (req, res){
        //validacion de datos que se reciben
        const errors = validationResult(req);

        if(!errors.isEmpty()){
            return res.status(400).json({status : 400, errors : errors.array()});
        }
        let n_mail = req.params.mail;
        let user_info = req.body;

        //if(!req.params.n_lista.isEmpty()) return res.status(501).send({message:"Parametro lista no enviado."  });
        //let alumnos_model= new Alumnos();
        Usuarios.findOneAndRemove({mail: n_mail},  (err, usuarioDelete) =>{
            if(err) return res.status(500).send({message: 'Error Eliminando usuario.'});
            if(!usuarioDelete) return res.status(404).json({message: 'No existe el usuario.'});

            return res.status(200).json({ 
                mensaje :"Datos usuario Eliminados"
            });

        });


    }




};

module.exports = controller;