'use strict';
const {validationResult} = require('express-validator');
const jwt = require('jsonwebtoken');


var Usuarios = require('../models/usuarios');
var Sessions = require('../models/sessions');
const { usuarios } = require('./usuarios');
var controller = {
    login: function (req, res) {

        const errors = validationResult(req);
        if(!errors.isEmpty()) {
            return res.status(400).json({
                errors: errors.array()
            });
        }
        //let login_info = req.body;
        let n_mail = req.body.mail;
        let n_pass = req.body.pass;

        Usuarios.findOne({mail : n_mail, pass: n_pass}).exec((err, usuario) => {
            if(err) return res.status(500).json({status : 500, mensaje : err});
            if(!usuario) return res.status(200).json({status :200, mensaje: "No se encontro el usuario."});

            //manejo del jwt
            const payload = {
                user_id: usuario.id
            };

            const access_token = jwt.sign(payload, 'cP22BcT5IM7C3MHfAMC2KezNCmsLdBX3A489Pz8rbPT5h4F0zA',{
                expiresIn: '1d'  //token de 1 dia
            });
            //console.log(access_token);
            let update = {
                user_id: usuario.id,
                jwt: access_token
            };

            Sessions.findOneAndUpdate({user_id: usuario.id,}, update, {upsert: true, new: true},(err, sessionsUpdate) => {
                if(err) return res.status(500).send({message: err});

                if(!sessionsUpdate) return res.status(404).send({message:"Datos erroneos."});

                return res.status(200).json({
                    status: 200,
                    mensaje : "Autenticacion correcta." ,
                    token: access_token  
                });

            });

            
        });


    },

    logout: function (req, res) {
        console.log(req.decoded);
        Sessions.findOneAndRemove({user_id: req.decoded.user_id},(err, usuarioDeleted)=> {
            if(err) return res.status(500).send({message: err});
            if(!usuarioDeleted) return res.status(404).send({message: "Datos erroneos"}); 
            
            return res.status(200).send({message: "Session finalizada. Token eliminado."});
       });
        
    }
};

module.exports = controller;