'use strict';
const {validationResult} = require('express-validator');

var Alumnos = require('../models/alumnos');
var controller = {
    alumnos: function (req, res)
    {
        Alumnos.find({}).exec((err, alumnos) => {
            if(err) return res.status(500).json({status : 500, mensaje : err});
            console.log(alumnos);
            return res.status(200).json({
                status: 200,
                data: alumnos
            }
            );
        });      
    },

    alumno: function (req, res)
    {
        //console.log(req);
        let n_lista = req.params.n_lista;
        Alumnos.findOne({n_cuenta : n_lista}).exec((err, alumno) => {
            if(err) return res.status(500).json({status : 500, mensaje : err});
            if(!alumno) return res.status(200).json({status :200, mensaje: "No se encontro el alumno."});

            return res.status(200).json({
                status : 200,
                data: alumno

            });
        }


        );
          
    },

    crear_alumno: function (req, res)
    {
        //validacion de datos que se reciben
        const errors = validationResult(req);

        if(!errors.isEmpty()){
            return res.status(400).json({status : 400, errors : errors.array()});
        }

        

        let user_info = req.body;

        Alumnos.findOne({n_cuenta : user_info.n_cuenta}).exec((err, alumno) => {
            if(err) return res.status(500).json({status : 500, mensaje : err});
            if(alumno) return res.status(200).json({status :200, mensaje: "El alumno ya existe."});

            let alumnos_model= new Alumnos();
            alumnos_model.n_cuenta = user_info.n_cuenta ;
            alumnos_model.nombre = user_info.nombre + user_info.apellido;
            alumnos_model.edad = user_info.edad;
            alumnos_model.genero = user_info.genero;



            alumnos_model.save((err, alumnoStored) => {
                if(err) return res.status(500).json({status : 500, mensaje : err});
                if(!alumnoStored) return res.status(200).json({status :200, mensaje: "No se almaceno el alumno."}); 
            });

            return res.status(200).json({
                status : 200,
                message: "Nuevo Usuario almacenado"
            });
        });
    },

    update_alumno: function (req, res){
        //validacion de datos que se reciben
        const errors = validationResult(req);

        if(!errors.isEmpty()){
            return res.status(400).json({status : 400, errors : errors.array()});
        }
        let n_lista = req.params.n_lista;
        let user_info = req.body;

        let alumno_info_update = {
            nombre: user_info.nombre,
            edad: user_info.edad,
            genero: user_info.genero
        
        };

        //let alumnos_model= new Alumnos();
        Alumnos.findOneAndUpdate({n_cuenta: n_lista}, alumno_info_update,{new:true}, (err, alumnoUpdate) =>{
            if(err) return res.status(500).send({message: 'Error actualizando.'});
            if(!alumnoUpdate) return res.status(404).json({message: 'No existe el alumno.'});

            return res.status(200).json({ 
                nombre: alumnoUpdate.nombre,
                edad: alumnoUpdate.edad,
                genero: alumnoUpdate.genero,
                mensaje :"Datos actualizados"
            });

        //console.log(user_info);

        });
},

    Elimina_alumno: function (req, res){
        //validacion de datos que se reciben
        const errors = validationResult(req);

        if(!errors.isEmpty()){
            return res.status(400).json({status : 400, errors : errors.array()});
        }
        let n_lista = req.params.n_lista;
        let user_info = req.body;

        //if(!req.params.n_lista.isEmpty()) return res.status(501).send({message:"Parametro lista no enviado."  });
        //let alumnos_model= new Alumnos();
        Alumnos.findOneAndRemove({n_cuenta: n_lista},  (err, alumnoDelete) =>{
            if(err) return res.status(500).send({message: 'Error Eliminando.'});
            if(!alumnoDelete) return res.status(404).json({message: 'No existe el alumno.'});

            return res.status(200).json({ 
                mensaje :"Datos Eliminados"
            });

        });


    }




};

module.exports = controller;