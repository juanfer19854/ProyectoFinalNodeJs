'use strict'
var controller = {
welcome: function (req, res){
    console.log("Get ejecutado en raiz");
    res.send("Hola mundo desde el GET");
}/*,

alumnos: function (req, res){
    res.send("Mi listado de alumnos");
},


alumno: function(req, res){
    let cal1 = 5;
    let cal2 = 5;
    let cal3 = 5;

    let final = (cal1 + cal2+ cal3) / 3;
    console.log (final);

    if(final < 6){
        return res.status(400).json({
            status : 400, 
            cal_final : final,
            mensaje : "Curso reprobado"});
    }
    else
    {
        //res.send("La calificacion final es : "+final);
        return res.status(200).json({
            status : 200, 
            cal_final : final,
            mensaje : "Curso aprobado"});
    }
    
},

crear_alumno: (req, res) => {

    let nombre = req.body.nombre;
    let apellido = req.body.apellido;
    let edad = req.body.edad;
    let user_info = req.body;

    console.log(req);

    //res.send("Creamos un alumno : " + nombre);

    return res.status(200).json({
        status : 200,  
        nombre_alumno : nombre + " " + apellido,
        edad_Alumno : edad});

},

actualizar_alumno: (req, res) => {
    res.send("Actualizamos un alumno");
},

borrar_alumno: (req, res) => {
    res.send("Eliminamos un alumno");
}
*/
};

module.exports = controller;