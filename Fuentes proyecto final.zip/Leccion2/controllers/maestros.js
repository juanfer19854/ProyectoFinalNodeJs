'use strict';
const {validationResult} = require('express-validator');

var Maestros = require('../models/maestros');
var controller = {
    Listar_maestros: function (req, res)
    {
        Maestros.find({}).exec((err, maestros) => {
            if(err) return res.status(500).json({status : 500, mensaje : err});
            console.log(maestros);
            return res.status(200).json({
                status: 200,
                data: maestros
            }
            );
        });      
    },

    maestro: function (req, res)
    {
        //console.log(req);
        let id_maestro = req.params.id_maestro;
        Maestros.findOne({id_maestro : id_maestro}).exec((err, maestro) => {
            if(err) return res.status(500).json({status : 500, mensaje : err});
            if(!maestro) return res.status(200).json({status :200, mensaje: "No se encontro el maestro."});

            return res.status(200).json({
                status : 200,
                data: maestro

            });
        }


        );
          
    },

    crear_maestro: function (req, res)
    {
        //validacion de datos que se reciben
        const errors = validationResult(req);

        if(!errors.isEmpty()){
            return res.status(400).json({status : 400, errors : errors.array()});
        }

        

        let user_info = req.body;

        Maestros.findOne({id_maestro : user_info.id_maestro}).exec((err, maestro) => {
            if(err) return res.status(500).json({status : 500, mensaje : err});
            if(maestro) return res.status(200).json({status :200, mensaje: "El maestro ya existe."});

            let maestros_model= new Maestros();
            maestros_model.n_cuenta = user_info.id_maestro ;
            maestros_model.nombre = user_info.nombre + user_info.apellido;
            maestros_model.edad = user_info.edad;
            maestros_model.genero = user_info.genero;
            maestros_model.especialidad = user_info.especialidad;



            maestros_model.save((err, maestroStored) => {
                if(err) return res.status(500).json({status : 500, mensaje : err});
                if(!maestroStored) return res.status(200).json({status :200, mensaje: "No se almaceno el maestro."}); 
            });

            return res.status(200).json({
                status : 200,
                message: "Nuevo maestro almacenado"
            });
        });
    },

    update_maestro: function (req, res){
        //validacion de datos que se reciben
        const errors = validationResult(req);

        if(!errors.isEmpty()){
            return res.status(400).json({status : 400, errors : errors.array()});
        }
        let id_maestro = req.params.id_maestro;
        let user_info = req.body;

        let maestro_info_update = {
            nombre: user_info.nombre,
            edad: user_info.edad,
            genero: user_info.genero,
            especialidad : user_info.especialidad
        
        };

        //let alumnos_model= new Alumnos();
        Maestros.findOneAndUpdate({id_maestro: id_maestro}, maestro_info_update,{new:true}, (err, maestroUpdate) =>{
            if(err) return res.status(500).send({message: 'Error actualizando.'});
            if(!maestroUpdate) return res.status(404).json({message: 'No existe el alumno.'});

            return res.status(200).json({ 
                nombre: maestroUpdate.nombre,
                edad: maestroUpdate.edad,
                genero: maestroUpdate.genero,
                especialidad: maestroUpdate.especialidad,
                mensaje :"Datos del maestro actualizados"
            });

        //console.log(user_info);

        });
},

    Elimina_maestro: function (req, res){
        //validacion de datos que se reciben
        const errors = validationResult(req);

        if(!errors.isEmpty()){
            return res.status(400).json({status : 400, errors : errors.array()});
        }
        let id_maestro = req.params.id_maestro;
        let user_info = req.body;

        //if(!req.params.n_lista.isEmpty()) return res.status(501).send({message:"Parametro lista no enviado."  });
        //let alumnos_model= new Alumnos();
        Maestros.findOneAndRemove({id_maestro: id_maestro},  (err, maestroDelete) =>{
            if(err) return res.status(500).send({message: 'Error Eliminando.'});
            if(!maestroDelete) return res.status(404).json({message: 'No existe el maestro.'});

            return res.status(200).json({ 
                mensaje :"Datos maestro Eliminados"
            });

        });


    }




};

module.exports = controller;