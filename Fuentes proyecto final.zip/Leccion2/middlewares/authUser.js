'use strict'
const jwt = require('jsonwebtoken');
let Sessions = require('../models/sessions');

const middlewares = {
    userProtectUrl: function(req, res, next) {
        const token = req.headers['access-token'];

        if(token){
            jwt.verify(token, 'cP22BcT5IM7C3MHfAMC2KezNCmsLdBX3A489Pz8rbPT5h4F0zA', (err, decoded) => {
                if(err){
                    return res.status(403).json({message: "Token invalido1"});
                }
                else{
                    req.decoded= decoded;
                    Sessions.findOne({user_id: req.decoded.user_id, jwt: token}).exec((err, session) => {
                        if(err) return req.status(500).send({message: "Error retornando los datos."});

                        if(!session) return res.status(404).send({message: "Los datos de autenticacion son invalidos."});
                        console.log(req.decoded);

                        next();
                    });
                    
                }
            });
        }
        else{
            res.status(403).send({Message: "Token no valido2."});
        }



    }
};
module.exports= middlewares;