'use strict'
const mongoose = require('mongoose');
const app = require('./app');  
const port = 3700; 

mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/curso',{useNewUrlParser:true, useUnifiedTopology:true})
        .then(()=> {
            console.log('Conexion a la bd'); 
            //crear el servidor
            var server = app.listen(port,()=> {
                console.log("Conectado a base de alumnos en la url :  http://Localhost: " + port);
            });
        })
        .catch((err => console.log(err)))
;