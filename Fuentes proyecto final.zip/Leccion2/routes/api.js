const express = require('express');
const api = express.Router();
const {body} = require('express-validator'); //middleware

var WelcomeController = require('../controllers/welcome');
var AlumnosController = require('../controllers/alumnos'); //
var UsuariosController = require('../controllers/usuarios'); //
var MaestrosController = require('../controllers/maestros'); //
let AuthController = require('../controllers/autorizador');
let userProtectUrl = require('../middlewares/authUser').userProtectUrl;


api.get("/", WelcomeController.welcome);
//alumnos
api.get("/alumnos", AlumnosController.alumnos);
api.get("/alumno/:n_lista", AlumnosController.alumno);
//el 2 parametro es para validar la existencia del tag genero dentro del consumo de la api
api.post("/alumno",userProtectUrl,
        [
            body('genero').not().isEmpty(),
            body('n_cuenta').not().isEmpty(),
            body('nombre').not().isEmpty(),
            body('edad').not().isEmpty()
        ], 
        AlumnosController.crear_alumno);
api.put("/alumno/:n_lista",[
    body('genero').not().isEmpty(),
    body('nombre').not().isEmpty(),
    body('edad').not().isEmpty()
], AlumnosController.update_alumno);

api.delete("/alumno/:n_lista",AlumnosController.Elimina_alumno);
api.delete("/alumno",AlumnosController.Elimina_alumno);
       

//usuarios
api.get("/usuarios", UsuariosController.usuarios);
api.get("/usuario/:mail", UsuariosController.usuario);
//el 2 parametro es para validar la existencia del tag genero dentro del consumo de la api
api.post("/usuario",
        [
            body('mail').not().isEmpty(),
            body('pass').not().isEmpty()
        ], 
        UsuariosController.crear_usuario);
api.put("/usuario/:mail",[
    body('pass').not().isEmpty()
], UsuariosController.update_usuario);

api.delete("/usuario/:mail",UsuariosController.Elimina_usuario);
api.delete("/usuario",UsuariosController.Elimina_usuario);

api.post("/login",
[body('mail').not().isEmpty(),
body('pass').not().isEmpty() ],
 AuthController.login);
api.post("/logout",userProtectUrl ,AuthController.logout);


//EJERCICIO END POINTS MAESTRO
api.get("/Listar_maestros", MaestrosController.Listar_maestros);
api.get("/alumno/:id_maestro", MaestrosController.maestro);
//crear
api.post("/maestro",userProtectUrl,
        [
            body('genero').not().isEmpty(),
            body('id_maestro').not().isEmpty(),
            body('nombre').not().isEmpty(),
            body('edad').not().isEmpty(),
            body('especialidad').not().isEmpty()
        ], 
        MaestrosController.crear_maestro);

//actualizar maestro
api.put("/maestro/:id_maestro",[
    body('genero').not().isEmpty(),
    body('nombre').not().isEmpty(),
    body('edad').not().isEmpty(),
    body('especialidad').not().isEmpty()
], MaestrosController.update_maestro);

//Elimina maestro

api.delete("/maestro/:id_maestro",MaestrosController.Elimina_maestro);


/*
api.get("/alumno", WelcomeController.alumno);
api.post("/alumno", WelcomeController.crear_alumno);
api.put("/alumno", WelcomeController.actualizar_alumno);
api.delete("/alumno", WelcomeController.borrar_alumno);
*/
module.exports = api;