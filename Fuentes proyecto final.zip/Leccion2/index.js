const express = require('express');
const app = express();
const port = 3700;

app.get('/', (req, res) => { 
    console.log("Get ejecuyado en raiz");
    res.send("Hola mundo desde el GET");
})

app.get('/alumnos', (req, res) => { 
   res.send("Mi listado de alumnos");
})



app.post('/alumno', (req, res) => { 
    
    res.send("CREAMOS UN ALUMNO : ");
})

app.put('/alumno', (req, res) => { 
    
    res.send("ACTUALIZMOS UN ALUMNO : ");
})

app.delete('/alumno', (req, res) => { 
    
    res.send("ELIMINAMOS UN ALUMNO : ");
})


app.listen(port,()=> {
    console.log("Servidor de ejemplo corriendo en puerto :  " + port);
});