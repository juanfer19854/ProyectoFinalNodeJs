'use strict';
var mongoose = require('mongoose');
var schema = mongoose.Schema;


var UsessionsSchema = schema({
    user_id :{type: String, require: true, unique: true} ,
    jwt: String
});

module.exports = mongoose.model('sessions', UsessionsSchema);