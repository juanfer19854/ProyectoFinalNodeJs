'use strict';
var mongoose = require('mongoose');
var schema = mongoose.Schema;


var MaestrosSchema = schema({
    id_maestro :{type: Number, require: true, unique: true} ,
    nombre: {type: String, require: true },
    edad: {type: Number, require: true },
    genero: {type: String, require: true },
    especialidad: {type: String, require: true }
});

module.exports = mongoose.model('maestros', MaestrosSchema);