'use strict';
var mongoose = require('mongoose');
var schema = mongoose.Schema;


var UsuariosSchema = schema({
    mail:{type: String, require: true, unique: true} ,
    pass: {type: String, require: true }
});

module.exports = mongoose.model('usuarios', UsuariosSchema);