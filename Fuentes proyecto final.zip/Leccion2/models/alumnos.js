'use strict';
var mongoose = require('mongoose');
var schema = mongoose.Schema;


var AlumnosSchema = schema({
    n_cuenta :{type: Number, require: true, unique: true} ,
    nombre: {type: String, require: true },
    edad: {type: Number, require: true },
    genero: {type: String, require: true }
     

});

module.exports = mongoose.model('alumnos', AlumnosSchema);
